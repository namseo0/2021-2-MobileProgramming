package com.cookandroid.a21_project;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class PaintBoard extends View {
    Canvas mCanvas;
    Bitmap mBitmap;
    Paint mPaint;

    int lastX;
    int lastY;

    public PaintBoard(Context context) {
        super(context);
        init(context);
    }

    public  PaintBoard(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    private  void init(Context context) {
        this.mPaint = new Paint();
        this.mPaint.setColor(Color.BLACK);

        this.lastX = -1;  // 최소 lastX 값을 –1로 설정
        this.lastY = -1;  // 최소 lastY 값을 –1로 설정
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        Bitmap img = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas();
        canvas.setBitmap(img);
        canvas.drawColor(Color.WHITE);
        mBitmap = img;
        mCanvas = canvas;
    }

    protected  void  onDraw(Canvas canvas) {
        if (mBitmap != null) {
            canvas.drawBitmap(mBitmap, 0,0,null);
        }
    }

    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getAction();

        int X = (int) event.getX();  // 현재 마우스가 있는 위치의 X 값 가져오기
        int Y = (int) event.getY();  // 현재 마우스가 있는 위치의 Y 값 가져오기

        switch (action) {

            case MotionEvent.ACTION_UP:
                lastX = -1;      // 마우스를 UP하면 lastX에 –1과  lastY에 –1으로 설정하여 마지막 점임을 알수 있음
                lastY = -1;
                break;

            case MotionEvent.ACTION_DOWN:
                if (lastX != -1) {
                    if (X != lastX || Y != lastY) {   // X와 lastX가 다르거나 Y와 lastY가 다른 경우 두점을 선으로 그린다.
                        mCanvas.drawLine(lastX, lastY, X, Y, mPaint);
                    }
                }

                lastX = X;   // 현재 값 X를 마지막 값 lastX 으로 설정
                lastY = Y;   // 현재 값 Y를 마지막 값 lastY 으로 설정
                break;

            case MotionEvent.ACTION_MOVE:
                if (lastX != -1) {  // 마우스가 UP되지 않으면 계속해서 두 점을 선으로 그림
                    mCanvas.drawLine(lastX, lastY, X, Y, mPaint);
                }
                lastX = X;
                lastY = Y;
                break;


        }
        invalidate();  // 화면이 무효화되고 onDraw() 메소드를 자동으로 실행한다.
        return true;
    }
}
