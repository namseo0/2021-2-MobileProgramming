package com.cookandroid.a21_project;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Project1 extends AppCompatActivity { //SEARCH 검색 - 웹브라우저 연결
    Button btnBack, btnGoogle, btnNaver;
    WebView web;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.project1);
        setTitle("SEARCH");
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        btnNaver = (Button) findViewById(R.id.btnNaver);
        btnGoogle = (Button) findViewById(R.id.btnGoogle);
        btnBack = (Button) findViewById(R.id.btnBack);
        web = (WebView) findViewById(R.id.webView1);

        web.setWebViewClient(new CookWebViewClient()); // CookWebViewClient()를 생성하여 웹뷰에 대입
        WebSettings webSet = web.getSettings();  // WebSettings 클래스를 이용하여
        webSet.setBuiltInZoomControls(true);     // 줌 버튼 컨트롤 화면이 보이게 함
        webSet.setJavaScriptEnabled(true);

        btnNaver.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                web.loadUrl("https://www.naver.com/");
            }
        });
        btnGoogle.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                web.loadUrl("https://www.google.com/");
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                web.goBack();
            }
        });
    }

    class CookWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return super.shouldOverrideUrlLoading(view, url);
        }
    }
}

