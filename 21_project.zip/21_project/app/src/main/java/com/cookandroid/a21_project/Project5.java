package com.cookandroid.a21_project;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class Project5 extends AppCompatActivity {
    final static int ZERO = 0, ROTATE = 1, TRANSFORM = 2, SCALE = 3, SKEW = 4;
    static int NUM = 0;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new MyGraphicView(this));
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 0, "이미지 회전");
        menu.add(0, 2, 0, "이미지 이동");
        menu.add(0, 3, 0, "이미지 크기 변경");
        menu.add(0, 4, 0, "이미지 기울이기");
        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                NUM = ROTATE;
                return true;
            case 2:
                NUM = TRANSFORM;
                return true;
            case 3:
                NUM = SCALE;
                return true;
            case 4:
                NUM = SKEW;
                return true;
        }
        return false;
    }

    private static class MyGraphicView extends View {
        public MyGraphicView(Context context) {
            super(context);
        }

        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            Bitmap picture = BitmapFactory.decodeResource(getResources(), R.drawable.me);
            int cenX = this.getWidth() / 2;
            int cenY = this.getHeight() / 2;
            int picX = (this.getWidth() - picture.getWidth()) / 2;
            int picY = (this.getHeight() - picture.getHeight()) / 2;
            switch (NUM) {
                case ZERO:
                    canvas.drawBitmap(picture, picX, picY, null);
                    break;
                case ROTATE:
                    canvas.rotate(45, cenX, cenY);
                    canvas.drawBitmap(picture, picX, picY, null);
                    break;
                case TRANSFORM:
                    canvas.translate(-150, 200);
                    canvas.drawBitmap(picture, picX, picY, null);
                    break;
                case SCALE:
                    canvas.scale(2, 2, cenX, cenY);
                    canvas.drawBitmap(picture, picX, picY, null);
                    break;
                case SKEW:
                    canvas.skew(0.3f, 0.3f);
                    canvas.drawBitmap(picture, picX, picY, null);
                    break;
            }
            invalidate();
            picture.recycle(); // 비트맵 리소스 해제
        }
    }
}