package com.cookandroid.a21_project;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class Project4 extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.project4);
        setTitle("MEMO");

        PaintBoard view = new PaintBoard(this);
        setContentView(view);
    }
}
