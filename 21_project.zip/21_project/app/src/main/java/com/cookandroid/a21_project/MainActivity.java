package com.cookandroid.a21_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.SlidingDrawer;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {
    Switch switchbtn;
    Button hallymbtn, itbtn, portfoliobtn, githubbtn, button0, button1, button2, button3, btnClose;
    Button btnMainProject, btnProject1, btnProject2, btnProject3, btnProject4, btnProject5;
    ImageButton me;
    SlidingDrawer slidingDrawer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Hi! I'm Seoyoung:)");//상단바 문구

        me = (ImageButton)findViewById(R.id.ImgBtn);
        hallymbtn = (Button)findViewById(R.id.hallymbtn);
        itbtn = (Button)findViewById(R.id.itbtn);
        portfoliobtn = (Button)findViewById(R.id.portfoliobtn);
        githubbtn = (Button)findViewById(R.id.githubbtn);
        slidingDrawer =(SlidingDrawer)findViewById(R.id.slidingDrawer);
        button0 = (Button)findViewById(R.id.button0);
        button1 = (Button)findViewById(R.id.button1);
        button2 = (Button)findViewById(R.id.button2);
        button3 = (Button)findViewById(R.id.button3);
        btnClose = (Button)findViewById(R.id.btnClose);
        btnMainProject = (Button)findViewById(R.id.btnMainProject);
        btnProject1 = (Button)findViewById(R.id.btnProject1);
        btnProject2 = (Button)findViewById(R.id.btnProject2);
        btnProject3 = (Button)findViewById(R.id.btnProject3);
        btnProject4 = (Button)findViewById(R.id.btnProject4);
        btnProject5 = (Button)findViewById(R.id.btnProject5);
        switchbtn = (Switch)findViewById(R.id.switchbtn);



        me.setOnClickListener(new View.OnClickListener() { //포트폴리오 사이트 연결
            @Override
            public void onClick(View view) {
                Intent intentSite1 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://sites.google.com/view/namseo0/home"));
                startActivity(intentSite1);
            }
        });
        hallymbtn.setOnClickListener(new View.OnClickListener() { //한림대학교 홈페이지 연결
            @Override
            public void onClick(View view) {
                Intent intentSite1 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.hallym.ac.kr/"));
                startActivity(intentSite1);
            }
        });
        itbtn.setOnClickListener(new View.OnClickListener() { //콘텐츠IT 페이지 연결
            @Override
            public void onClick(View view) {
                Intent intentSite2 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://sw.hallym.ac.kr/index.php?mp=2_3"));
                startActivity(intentSite2);
            }
        });
        portfoliobtn.setOnClickListener(new View.OnClickListener() { //포트폴리오 사이트 연결
            @Override
            public void onClick(View view) {
                Intent intentSite3 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://sites.google.com/view/namseo0/home"));
                startActivity(intentSite3);
            }
        });
        githubbtn.setOnClickListener(new View.OnClickListener() { //깃허브 연결
            @Override
            public void onClick(View view) {
                Intent intentSite3 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/namseo0"));
                startActivity(intentSite3);
            }
        });

        btnClose.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SlidingDrawer drawer = (SlidingDrawer)findViewById(R.id.slidingDrawer);
                drawer.animateClose();//서랍 닫기

                hallymbtn.setVisibility(View.VISIBLE);
                itbtn.setVisibility(View.VISIBLE);
                portfoliobtn.setVisibility(View.VISIBLE);
                githubbtn.setVisibility(View.VISIBLE);
                me.setVisibility(View.VISIBLE);
                button0.setVisibility(View.VISIBLE);
                button1.setVisibility(View.VISIBLE);
                button2.setVisibility(View.VISIBLE);
                button3.setVisibility(View.VISIBLE);
            }
        });

        switchbtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(switchbtn.isChecked() == true) { //스위치 체크 시 메인화면 버튼 안보이게
                    hallymbtn.setVisibility(View.GONE);
                    itbtn.setVisibility(View.GONE);
                    portfoliobtn.setVisibility(View.GONE);
                    githubbtn.setVisibility(View.GONE);
                    me.setVisibility(View.GONE);
                    button0.setVisibility(View.GONE);
                    button1.setVisibility(View.GONE);
                    button2.setVisibility(View.GONE);
                    button3.setVisibility(View.GONE);
                }
                else {
                    hallymbtn.setVisibility(View.VISIBLE);
                    itbtn.setVisibility(View.VISIBLE);
                    portfoliobtn.setVisibility(View.VISIBLE);
                    githubbtn.setVisibility(View.VISIBLE);
                    me.setVisibility(View.VISIBLE);
                    button0.setVisibility(View.VISIBLE);
                    button1.setVisibility(View.VISIBLE);
                    button2.setVisibility(View.VISIBLE);
                    button3.setVisibility(View.VISIBLE);
                }
            }
        });

        //메인 프로젝트로 이동
        btnMainProject.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Project_Main.class);
                startActivity(intent);
            }
        });
        //과제1로 이동
        btnProject1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent1 = new Intent(getApplicationContext(), Project1.class);
                startActivity(intent1);
            }
        });
        //과제2로 이동
        btnProject2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent2 = new Intent(getApplicationContext(), Project2.class);
                startActivity(intent2);
            }
        });
        //과제3으로 이동
        btnProject3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent3 = new Intent(getApplicationContext(), Project3.class);
                startActivity(intent3);
            }
        });
        //과제4로 이동
        btnProject4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent4 = new Intent(getApplicationContext(), Project4.class);
                startActivity(intent4);
            }
        });
        //과제5로 이동
        btnProject5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent5 = new Intent(getApplicationContext(), Project5.class);
                startActivity(intent5);
            }
        });
    }
}