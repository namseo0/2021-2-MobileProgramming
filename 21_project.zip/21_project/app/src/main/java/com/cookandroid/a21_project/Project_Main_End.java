package com.cookandroid.a21_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Project_Main_End extends AppCompatActivity {
    Button btnEnd, btnBack;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.project_main_end);
        setTitle("STUDY END");

        btnBack = (Button)findViewById(R.id.btnBack);
        btnEnd = (Button)findViewById(R.id.btnEnd);

        btnBack.setOnClickListener(new View.OnClickListener() { //프로젝트 화면으로 이동
            public void onClick(View view) {
                Intent intentback = new Intent(getApplicationContext(), Project_Main.class);
                startActivity(intentback);
            }
        });

        btnEnd.setOnClickListener(new View.OnClickListener() { //메인화면으로 이동
            public void onClick(View view) {
                Intent intentEnd = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intentEnd);
            }
        });

    }
}