package com.cookandroid.a21_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Project_Main_Tool extends AppCompatActivity {
    Button btn1, btn2, btn3, btn4, btn5, btnexit;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.project_main_tool);
        setTitle("STUDY TOOL");

        btnexit = (Button)findViewById(R.id.btnExit); //이전 창으로 돌아가기
        btnexit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intentE = new Intent(getApplicationContext(), Project_Main.class);
                startActivity(intentE);
            }
        });

        //각 프로젝트로 이동
        btn1 = (Button)findViewById(R.id.btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent01 = new Intent(getApplicationContext(), Project1.class);
                startActivity(intent01);
            }
        });

        btn2 = (Button)findViewById(R.id.btn2);
        btn2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent02 = new Intent(getApplicationContext(), Project2.class);
                startActivity(intent02);
            }
        });

        btn3 = (Button)findViewById(R.id.btn3);
        btn3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent03 = new Intent(getApplicationContext(), Project3.class);
                startActivity(intent03);
            }
        });

        btn4 = (Button)findViewById(R.id.btn4);
        btn4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent04 = new Intent(getApplicationContext(), Project4.class);
                startActivity(intent04);
            }
        });
    }
}