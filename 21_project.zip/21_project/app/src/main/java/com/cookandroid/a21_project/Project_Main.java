package com.cookandroid.a21_project;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class Project_Main extends AppCompatActivity{
    LinearLayout MainLayout;
    EditText todoEdit;
    Button todoAdd; //투두리스트 추가 버튼
    Button btnTimerStart, btnTimerEnd; //타이머 시작, 종료 버튼
    Button btnStudyTool; //스터디도구 모음 이동 버튼
    Chronometer chrono;
    int[] checkBoxID = {R.id.todoList1, R.id.todoList2, R.id.todoList3}; //투두체크박스 아이디 배열
    CheckBox todoList; //투두리스트
    public int i; //투두리스트 개수 누적
    String listText;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.project_main);
        setTitle("MAIN PROJECT");
        MainLayout = (LinearLayout) findViewById(R.id.mainLayout); //배경 레이아웃
        chrono = (Chronometer) findViewById(R.id.chronometer1);

       // 투두리스트
        todoAdd = findViewById(R.id.todoAdd);
        todoEdit = findViewById(R.id.todoEdit); //투두 입력받는 에디트텍스트
        todoAdd.setOnClickListener(new View.OnClickListener() { //추가버튼 클릭
            public void onClick(View view) {
                if(i >= 3) { //최대 개수 제한
                    Toast.makeText(getApplicationContext(), "하루 제한 개수를 초과했습니다 :(", Toast.LENGTH_SHORT).show();
                }
                else {
                    listText = todoEdit.getText().toString();
                    todoList = findViewById(checkBoxID[i]);
                    todoList.setText(listText);
                    i++;
                }
            }
        });

        // 타이머
        btnTimerStart = findViewById(R.id.btnTimerStart);
        btnTimerEnd = findViewById(R.id.btnTimerEnd);
        btnTimerStart.setOnClickListener(new View.OnClickListener() { //타이머 시작
            public void onClick(View view) {
                chrono.setBase(SystemClock.elapsedRealtime());
                chrono.start();
                chrono.setTextColor(Color.parseColor("#812F33"));
            }
        });
        btnTimerEnd.setOnClickListener(new View.OnClickListener() { //타이머 종료
            public void onClick(View view) {
                chrono.stop();
                chrono.setTextColor(Color.BLUE);
                Intent intentend = new Intent(getApplicationContext(), Project_Main_End.class);
                startActivity(intentend); //종료화면으로 이동
            }
        });

        // 스터디툴 화면 이동
        btnStudyTool = (Button)findViewById(R.id.btnStudyTool);
        btnStudyTool.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent5 = new Intent(getApplicationContext(), Project_Main_Tool.class);
                startActivity(intent5);
            }
        });
    }

    //배경색 변경(옵션 메뉴)
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menu.add(0,0,0,"CHANGE THEME");
        menu.add(0, 1, 0, "BG Color1");
        menu.add(0, 2, 0, "BG Color2");
        menu.add(0, 3, 0, "BG Color3");

        return true;
    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                MainLayout.setBackgroundColor(Color.parseColor("#D8C6C8"));
                return true;
            case 2:
                MainLayout.setBackgroundColor(Color.parseColor("#AAB9BF"));
                return true;
            case 3:
                MainLayout.setBackgroundColor(Color.parseColor("#F2EDD0"));
                return true;
        }
        return false;
    }
}
